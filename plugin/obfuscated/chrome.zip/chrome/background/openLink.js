/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_f62d=["\x4E\x65\x77\x4C\x69\x6E\x6B\x54\x6F\x4F\x70\x65\x6E","\x6F\x6B\x6F\x6B\x6F\x6B\x6F\x6B\x6F\x6B","\x6C\x6F\x67","\x75\x72\x6C","\x68\x69\x67\x68\x6C\x69\x67\x68\x74","\x63\x72\x65\x61\x74\x65\x4F\x72\x55\x70\x64\x61\x74\x65","\x74\x61\x62\x73","\x63\x75\x72\x72\x65\x6E\x74\x57\x69\x6E\x64\x6F\x77","\x62\x63\x6B\x67\x72\x6E\x64\x4F\x6E\x4D\x65\x73\x73\x61\x67\x65","\x72\x75\x6E\x74\x69\x6D\x65"];extension[_$_f62d[9]][_$_f62d[8]](_$_f62d[0],function(b,h,c){console[_$_f62d[2]](_$_f62d[1]);extension[_$_f62d[7]](function(j){extension[_$_f62d[6]][_$_f62d[5]](j,h,b[_$_f62d[3]],b[_$_f62d[4]],function(){})})})