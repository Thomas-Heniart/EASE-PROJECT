/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_9ff9=["\x74\x6F\x70","\x6C\x6F\x67\x6F\x75\x74","\x6F\x6E\x4D\x65\x73\x73\x61\x67\x65","\x72\x75\x6E\x74\x69\x6D\x65"];if(window[_$_9ff9[0]]=== window){extension[_$_9ff9[3]][_$_9ff9[2]](_$_9ff9[1],function(b,c){doThings(b,c);logoutOverlay(b)})}