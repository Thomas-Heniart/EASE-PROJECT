/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_2e23=["\x6F\x70\x65\x6E\x2D\x65\x61\x73\x65","\x68\x74\x74\x70\x3A\x2F\x2F\x65\x61\x73\x65\x2E\x73\x70\x61\x63\x65","\x6F\x70\x65\x6E","\x61\x64\x64\x53\x68\x6F\x72\x74\x43\x75\x74"];extension[_$_2e23[3]](function(w){if(w== _$_2e23[0]){window[_$_2e23[2]](_$_2e23[1])}})