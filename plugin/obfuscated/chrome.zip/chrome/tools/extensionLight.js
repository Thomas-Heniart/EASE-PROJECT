/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_f361=["\x73\x65\x6E\x64\x4D\x65\x73\x73\x61\x67\x65","\x72\x75\x6E\x74\x69\x6D\x65","\x6E\x61\x6D\x65","\x6D\x65\x73\x73\x61\x67\x65","\x61\x64\x64\x4C\x69\x73\x74\x65\x6E\x65\x72","\x6F\x6E\x4D\x65\x73\x73\x61\x67\x65"];var extensionLight={runtime:{sendMessage:function(x,b,s){chrome[_$_f361[1]][_$_f361[0]]({"\x6E\x61\x6D\x65":x,"\x6D\x65\x73\x73\x61\x67\x65":b},s)},onMessage:function(x,y){chrome[_$_f361[1]][_$_f361[5]][_$_f361[4]](function(m,z,c){if(m[_$_f361[2]]== x){y(m[_$_f361[3]],c);return true}})}}}