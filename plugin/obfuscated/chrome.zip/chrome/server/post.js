var server = {
    post:function(string){
        console.log(string);
    }
}