$( '#toto' ).draggable();
