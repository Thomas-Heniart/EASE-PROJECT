var Content = function() {
	console.log("addWebsiteAction");
	
	if (context.getType() === 'tab') {

		I.cleanDom = function(dom) {
			var scripts = dom.getElementsByTagName('script');
			console.log(scripts.length + " scripts");
			for (var i = (scripts.length - 1); i >= 0; i--) {
				scripts[i].parentNode.removeChild(scripts[i]);
			};

			var styles = dom.getElementsByTagName('style');
			console.log(styles.length + " styles");
			for (var i = (styles.length - 1); i >= 0; i--) {
				styles[i].parentNode.removeChild(styles[i]);
			};
		}

		var firstDom = document.getElementsByTagName('body')[0].cloneNode(true);
		I.cleanDom(firstDom);
		var domUrl = window.location.href;
		var domDomain = window.location.host;
		console.log(domUrl);
		var observer = new MutationObserver(function(mutations) {
 			console.log("changements");
		});
		var config = { attributes: true, subtree: true, characterData: true };
		observer.observe(document.querySelector('body'), config);

		if (I.memory.state == undefined) {
			I.memory.state = "GoToHomePage";
			I.pushMemory();
		}
		I.import("GoToHomePagePopupJS", function() {
			var AddWebsitePopup;
			var text;
			var onDone = {};
			onDone.home = function() {
				I.sendMessage("unconnectedDom", {'url':domUrl, 'domain':domDomain, 'dom':firstDom.innerHTML});
				AddWebsitePopup.getLoggedPage();
				I.memory.state = "Loggin";
				I.pushMemory();
				AddWebsitePopup.onDone(onDone.loggin);
			}
			onDone.loggin = function() {
				I.sendMessage("connectedDom", {'url':domUrl, 'domain':domDomain, 'dom':firstDom.innerHTML});
				AddWebsitePopup.getLoggedOutPage();	
				I.memory.state = "Loggout";
				I.pushMemory();
				AddWebsitePopup.onDone(onDone.loggout);
			}
			onDone.loggout = function() {
				I.sendMessage("loggedOutDom", {'url':domUrl, 'domain':domDomain, 'dom':firstDom.innerHTML});
				AddWebsitePopup.remove();
				I.finish();
			}
			if (I.memory.state === "GoToHomePage") {
				text = "Go to the website's home page.";
				onDone.actualy = onDone.home;
			} else if (I.memory.state === "Loggin") {
				text = "Please connect you.";
				onDone.actualy = onDone.loggin;
			} else if (I.memory.state === "Loggout") {
				text = "Please loggout you.";
				onDone.actualy = onDone.loggout;
			}

			AddWebsitePopup = new I.AddWebsitePopup(text);
			AddWebsitePopup.onDone(onDone.actualy);

		});
	}

}