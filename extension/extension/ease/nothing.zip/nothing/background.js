var Background = function() {

	console.log("creation background");
	global.launchAddWebsite = function() {
		browserManager.getWindows()[0].openTab("https://google.com/", function(tab) {
			tab.launchAction("addWebsite");
		});
	}

	this.destroy = function() {
		console.log("destruction background");
	}
}