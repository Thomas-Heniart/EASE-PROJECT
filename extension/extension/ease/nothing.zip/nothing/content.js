var Content = function() {

	console.log("content created2");
	this.destroy = function() {
		console.log("destruction content");
	}
}